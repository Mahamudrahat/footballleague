<?php 

$host="localhost";
$user="";
$password="";
$db="football_db";

$conn = new mysqli($host, $user, $password, $db);

if(isset($_POST['username'])){
    
    $uname=$_POST['username'];
    $password=$_POST['password'];
    
    $sql="select * from login where username='".$uname."'AND password='".$password."'";
    
    $result = $conn->query($sql);
    
    if($result->num_rows > 0){
        echo " You Have Successfully Logged in";
        header("location:afterlogin.php");
        exit();
    }
    else{
        echo " You Have Entered Incorrect Password";
        exit();
    }
        
}
?>