<?php 

$host="localhost";
$user="";
$password="";
$db="football_db";

$conn = new mysqli($host, $user, $password, $db);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['username'])){
    
    $uname=$_POST['username'];
    $password=$_POST['password'];
    
    $sql="INSERT INTO login (username, password) VALUES ('$uname','$password')";
    
    
    
   if(mysqli_query($conn, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. ". $conn->connect_error ;
}
        
}
?>