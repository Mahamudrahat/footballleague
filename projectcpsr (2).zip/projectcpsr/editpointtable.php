<html>
<head>
	<title>Edit Point Table</title>
	<link href="editpointtable.css" rel="stylesheet" type="text/css"/>
	 <script src="js/jquery-1.3.2.min.js"></script>
  <script src="js/jquery.nivo.slider.js"></script>
  <script src="js/jquery-migrate-1.2.1.min.js"></script>
  <script src="js/jquery.cycle.all.min.js"></script>
</head>
<body>
	<div id="main">
   <div id="header1">
          <img src="pic1.png" width="130" height="120" align="left"></a>
      
        </div>

        <div id="header2">
         <h2>CPSCRIAN SOCCER MANIA  2019</h2>
      
        </div>
     <div id="header3">
           
          <img src="pic2.png" width="130" height="110" align="right"></a>

      </div>
     
     <div id="youtubelog">
          <a href="https://www.youtube.com/"><img src="youtube.png" width="30" height="30" align="right" ></a>
      </div>
      <div id="facebooklog">
          <a href="https://www.facebook.com/CPSCRian-Soccer-Mania-2335249946722536/"><img src="facebook4.png" width="30" height="23" align="right"  ></a>
      
     
  
     </div>
         
    <div id="header">  
      <h1><h1>
        
       
        

</div>

<div id="mainmenu">
<ul>
<li><a href="slider.html">Home</a></li>
<li><a href="about.html">About Us</a></li>
<li><a href="">Teams</a></li>
<li><a href="matches.html">Matches</a></li>
<li><a href="statics.php">Statistics</a></li>
<li><a href="teams.html">Gallery</a></li>
<li><a href="adminpannel.php">Admin Panel</a></li>
<li><a href="registration.php">Registration</a></li>
<li><a href="edit.php">Edit Score</a></li>
<li><a href="editpointtable.php">Edit Point Table</a></li>

</ul>
</div>
<div id="slider">


	<?php 

$servername = "localhost";
$username = "";
$password = "";
$dbname = "football_db";
 
// Creating mysql connection
$conn = new mysqli($servername, $username, $password, $dbname);
 
// Checking mysql connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
 
// Writing a mysql query to retrieve data 
$sql = "SELECT id,team FROM stat";
$result = $conn->query($sql);






	?>
<html>
<body>

	   <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	   	<div class="form-input">

        <label class="label">Select Team</label>
       <select class="select"  name="MN">
            
            <?php while($row1 = $result->fetch_assoc()){

              #$array[]=$row1["id"];
             
              ?>


            <option value="<?php echo $row1["team"];?>" ><?php echo $row1["team"];?></option>
           
      
     <?php }?>
     
          
	</select>

        
  <input type="submit" name="submit" value="SELECT" class="btn-login"/>
	  </div>

</form>


     <?php 
if (!empty($_POST['submit'])) { 

  $id1=$_POST['MN'];

  $sql1="SELECT m_no,team,win,lost,no_res,point FROM stat WHERE team='".$id1."'";

  $result1 = $conn->query($sql1);
  if ($result1->num_rows > 0) {
     
  // Show each data returned by mysql
  while($row = $result1->fetch_assoc()) {?>
     <form method="POST" action="editpointableupdate.php">
    <div class="form-input">
      <label class="label">Number of Match: </label>

     <input type="text" name="m_no" value="<?php echo $row['m_no']?>" class="text" />

    <label class="label1">Team</label>

     <input type="text" name="team" value="<?php echo $row['team']?>" class="text" readonly="readonly"/>

    <label class="label2">Win</label>

     <input type="text1" name="win" value="<?php echo $row['win']?>" class="text1"/>

        <label class="label2">Lost</label>

     <input type="text1" name="lost" value="<?php echo $row['lost']?>" class="text1"/>

        <label class="label2">NO Result</label>

     <input type="text1" name="no_res" value="<?php echo $row['no_res']?>" class="text1"/>

          <label class="label2">Point</label>

     <input type="text1" name="point" value="<?php echo $row['point']?>" class="text1" readonly="readonly"/>

      <input type="submit" name="submit1" value="Update" class="btn-login1"/>
 </div>
 </form>

<?php
}
 
 } 

}

?>


      


</div>


<div class="footer">
 
<p class="left">&copy;All Reserved & Developed By MD. Mahamud Hasan (Rahat)</p>  


 <p class="right">&copy;Designed by : Md. Musayek Hossain (Ridoy)</p> 
 
</div>

</div>

	
</body>
</html>