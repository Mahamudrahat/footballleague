<?php 

$host="localhost";
$user="";
$password="";
$db="football_db";

$conn = new mysqli($host, $user, $password, $db);
  
    $point=0;
   
    $m_no=$_POST['m_no'];
    $team=$_POST['team'];
    $win=$_POST['win'];
    $lost=$_POST['lost'];
    $no_res=$_POST['no_res'];
    if($m_no>0){
    $point=($win*3)+($no_res*1);
    }
    else {
    	$point=0;
    }
    
    $sql="UPDATE stat SET m_no='$m_no',win='$win',lost='$lost',no_res='$no_res',point='$point' where team='$team'";
    $result = $conn->query($sql);
    echo "HELLO";
    

    
        

?>