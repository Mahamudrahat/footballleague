<?php 

$host="localhost";
$user="";
$password="";
$db="football_db";

$conn = new mysqli($host, $user, $password, $db);


    $id1=$_POST['mi'];
    $g1=$_POST['goal1'];
    $g2=$_POST['goal2'];
    
    $sql="UPDATE match_tb SET goal1='$g1',goal2='$g2' where id='$id1'";
    $result = $conn->query($sql);
     echo $g1;
     echo $g2;
    echo "HELLO";
    

    
        

?>