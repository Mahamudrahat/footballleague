<html>
<head>
	<title>Group</title>
	<link href="groupa.css" rel="stylesheet" type="text/css"/>
	 <script src="js/jquery-1.3.2.min.js"></script>
  <script src="js/jquery.nivo.slider.js"></script>
  <script src="js/jquery-migrate-1.2.1.min.js"></script>
  <script src="js/jquery.cycle.all.min.js"></script>
</head>
<body>
	<div id="main">
 <div id="header1">
          <img src="pic1.png" width="130" height="120" align="left"></a>
      
        </div>

        <div id="header2">
         <h2>CPSCRIAN SOCCER MANIA  2019</h2>
      
        </div>
     <div id="header3">
           
          <img src="pic2.png" width="130" height="110" align="right"></a>

      </div>
     
     <div id="youtubelog">
          <a href="https://www.youtube.com/"><img src="youtube.png" width="30" height="30" align="right" ></a>
      </div>
      <div id="facebooklog">
          <a href="https://www.facebook.com/CPSCRian-Soccer-Mania-2335249946722536/"><img src="facebook4.png" width="30" height="23" align="right"  ></a>
      
     
  
     </div>
       
    <div id="header">  
      <h1><h1>
        
        
       
        

</div>

<div id="mainmenu">
<ul>
<li><a href="slider.html">Home</a></li>
<li><a href="about.html">About Us</a></li>
<li><a href="teams.html">Teams</a></li>
<li><a href="matches.html">Matches</a></li>
<li><a href="statics.php">Statistics</a></li>
<li><a href="">Gallery</a></li>
<li><a href="adminpannel.php">Admin Panel</a></li>

</ul>
</div>
<div id="slider">
<div id=group>
<ul>
<li><a href="grouptest1.php">Day1 (14.08.2019)</a></li>
<li><a href="">Day2</a></li>
<li><a href="">Day3</a></li>
<li><a href="">Day4</a></li>
<li><a href="">Day5</a></li>
<li><a href="">SEMI Final</a></li>
<li><a href="">Final</a></li>
</ul>	
</div>
<div id="sideber">


  <?php
// Server credentials 
$servername = "localhost";
$username = "";
$password = "";
$dbname = "football_db";
 
// Creating mysql connection
$conn = new mysqli($servername, $username, $password, $dbname);
 
// Checking mysql connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
 
// Writing a mysql query to retrieve data 
$sql = "SELECT grop,day,teama,teamb,img1,img2,goal1,goal2,date FROM match_tb where day=1";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
  // Show each data returned by mysql
  while($row = $result->fetch_assoc()) {
   
  
  ?>
   <h1><img src="<?php echo $row["img1"];?>" hieght="30" width="30"  style=" padding: 0px 10px 0px 0px;""><?php echo "". $row["teama"]."      ".$row["goal1"]."     vs                ".$row["goal2"]." ";?><img src="<?php echo $row["img2"];?>" hieght="30" width="30"  style=" padding: 0px 10px 0px 0px;""> <?php echo "".$row["teamb"]. "       " . $row["date"] . "<br>"; ?></h1>
 
<?php


  }
  
} else {
  echo "0 results";
}
 
// Closing mysql connection
$conn->close();
?>

	</div>
</div>





<div class="footer">
 
<p class="left">&copy;All Reserved & Developed By MD. Mahamud Hasan (Rahat)</p>  


 <p class="right">&copy;Designed by : Md. Musayek Hossain (Ridoy)</p> 
 
</div>

</div>

	
</body>
</html>