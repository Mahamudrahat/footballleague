<html>
<head>
	<title>Point Table</title>
	<link href="statics.css" rel="stylesheet" type="text/css"/>
	 <script src="js/jquery-1.3.2.min.js"></script>
  <script src="js/jquery.nivo.slider.js"></script>
  <script src="js/jquery-migrate-1.2.1.min.js"></script>
  <script src="js/jquery.cycle.all.min.js"></script>
</head>
<body>
	<div id="main">
 <div id="header1">
          <img src="pic1.png" width="130" height="120" align="left"></a>
      
        </div>

        <div id="header2">
         <h2>CPSCRIAN SOCCER MANIA  2019</h2>
      
        </div>
     <div id="header3">
           
          <img src="pic2.png" width="130" height="110" align="right"></a>

      </div>
     
     <div id="youtubelog">
          <a href="https://www.youtube.com/"><img src="youtube.png" width="30" height="30" align="right" ></a>
      </div>
      <div id="facebooklog">
          <a href="https://www.facebook.com/CPSCRian-Soccer-Mania-2335249946722536/"><img src="facebook4.png" width="30" height="23" align="right"  ></a>
      
     
  
     </div>
      
    <div id="header">  
      <h1><h1>
        
        
       
        

</div>

<div id="mainmenu">
<ul>
<li><a href="slider.html">Home</a></li>
<li><a href="about.html">About Us</a></li>
<li><a href="">Teams</a></li>
<li><a href="matches.html">Matches</a></li>
<li><a href="statics.php">Statistics</a></li>
<li><a href="">Gallery</a></li>
<li><a href="adminpannel.php">Admin Panel</a></li>

</ul>
</div>
<div id="slider">

	<table>
   <tr>
     <th>Team</th>
     <th>Match</th>
     <th>W</th>
     <th>L</th>
     <th>N/R</th>
     <th>P</th>
   </tr> 
   <?php
// Server credentials 
$servername = "localhost";
$username = "";
$password = "";
$dbname = "football_db";
 
// Creating mysql connection
$conn = new mysqli($servername, $username, $password, $dbname);
 
// Checking mysql connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
 
// Writing a mysql query to retrieve data 
$sql = "SELECT team,m_no,win,lost,no_res,point FROM stat";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
  // Show each data returned by mysql
  while($row = $result->fetch_assoc()) {
  echo "<tr><td>". $row["team"]."</td><td>".$row["m_no"]."</td><td>".$row["win"]."</td><td>".$row["lost"]."</td><td>".$row["no_res"]."</td><td>".$row["point"]."</td></tr>";
  }
   echo "</table>";
}
else{
  echo " no result";
}

  $conn->close();

  ?>
  </table>

</div>


<div class="footer">
 
<p class="left">&copy;All Reserved & Developed By MD. Mahamud Hasan (Rahat)</p>  


 <p class="right">&copy;Designed by : Md. Musayek Hossain (Ridoy)</p> 
 
</div>

</div>

	
</body>
</html>