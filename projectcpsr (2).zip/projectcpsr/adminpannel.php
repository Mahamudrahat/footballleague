
<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link href="adminpannel.css" rel="stylesheet" type="text/css"/>
    <link href="fontawesome.min.css" rel="stylesheet" type="text/css"/>
</head>
<body>
	<div class="container">
	<img src="login.jpg"/>
		<form method="POST" action="login.php">
		<div class="form-input">
		<input type="text" name="username" placeholder="Enter the User Name"/>	
		</div>
		<div class="form-input">
		<input type="password" name="password" placeholder="password"/>
		</div>
		<input type="submit" type="submit" value="LOGIN" class="btn-login"/>
		</form>
	</div>
</body>
</html>